# SurgeryBox V3 3.1.0 / protocol=8

先读[交接说明](docs/AI-HANDOFF.md)和[硬件接口](docs/v3-hardware-api.md)。

安装：`python -m pip install -r host_sdk/requirements-gui.txt`

测试端：`python tools/v3_test_client.py --port COM4`；Windows可双击`tools/StartHardwareTest.cmd`。

上电位置自动作回卷零点，无人工两端标定、无拉出上限、无提前停车死区；舵机75°/秒。

固件源码在firmware/v3；已烧录镜像和现场证据在releases/surgerybox-v3-3.1.0。
包内SHA256.json逐文件列出校验值；剩余问题见交接说明。
