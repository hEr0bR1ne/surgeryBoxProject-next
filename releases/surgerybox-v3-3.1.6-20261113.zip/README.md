# SurgeryBox V3 3.1.6 / protocol=8

先读[交接说明](docs/AI-HANDOFF.md)和[硬件接口](docs/v3-hardware-api.md)。

安装：`python -m pip install -r host_sdk/requirements-gui.txt`

测试端：`python tools/v3_test_client.py --port COM4`；Windows可双击`tools/StartHardwareTest.cmd`。

上电自动设零点，也可手动设置实际回卷零点。D8 回卷，D7 释放；舵机目标 180°/90°/30°。

固件源码在 firmware/v3。已烧录镜像和现场证据在 releases/surgerybox-v3-3.1.6。
包内SHA256.json逐文件列出校验值；剩余问题见交接说明。
